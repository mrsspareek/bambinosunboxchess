'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { GameHistoryItem } from '../../types/chess';
import { History, Flame, Star, Play, Plus, Minus, Clock, ShieldCheck, Zap } from 'lucide-react';

const MOCK_HISTORY: GameHistoryItem[] = [
  {
    id: "g-1",
    date: "Today, 1:15 PM",
    opponent: "Invited Friend Match",
    pieceIcon: "/pieces/wN.svg",
    matchType: "invited",
    result: "loss",
    accuracy: 62.1,
    timeControl: "10:00",
    movesCount: 32,
    isBot: false,
    pgn: "1.e4 e5 2.Nf3 Nc6..."
  },
  {
    id: "g-2",
    date: "Today, 12:45 PM",
    opponent: "Pass & Play Match",
    pieceIcon: "/pieces/bR.svg",
    matchType: "pass_play",
    result: "loss",
    accuracy: 58.4,
    timeControl: "10:00",
    movesCount: 28,
    isBot: false,
    pgn: "1.d4 d5 2.c4 e6..."
  },
  {
    id: "g-3",
    date: "Today, 11:30 AM",
    opponent: "Coach Zaid Practice",
    pieceIcon: "/pieces/wQ.svg",
    matchType: "coach",
    result: "win",
    accuracy: 68.4,
    timeControl: "10:00",
    movesCount: 24,
    isBot: false,
    pgn: "1.e4 c5 2.Nf3 d6..."
  },
  {
    id: "g-4",
    date: "Yesterday, 4:15 PM",
    opponent: "Invited Friend Match",
    pieceIcon: "/pieces/bB.svg",
    matchType: "invited",
    result: "win",
    accuracy: 76.5,
    timeControl: "10:00",
    movesCount: 36,
    isBot: false,
    pgn: "1.e4 e5 2.Bc4..."
  },
  {
    id: "g-5",
    date: "Yesterday, 2:30 PM",
    opponent: "AI Bot Practice",
    pieceIcon: "/pieces/bN.svg",
    matchType: "bot",
    result: "win",
    accuracy: 81.0,
    timeControl: "10:00",
    movesCount: 20,
    isBot: true,
    pgn: "1.e4 e5 2.Qh5..."
  }
];

export default function HistoryPage() {
  const [userName, setUserName] = useState('Student Player');
  const [historyList, setHistoryList] = useState<GameHistoryItem[]>(MOCK_HISTORY);

  useEffect(() => {
    try {
      const storedUser = localStorage.getItem('unbox_student_user');
      if (storedUser) {
        const u = JSON.parse(storedUser);
        if (u && u.name && u.name.trim() !== '' && u.name.toLowerCase() !== 'zaid iqbal') {
          setUserName(u.name.trim());
        }
      }

      const storedHistory = localStorage.getItem('unbox_game_history');
      if (storedHistory) {
        const parsed = JSON.parse(storedHistory);
        if (Array.isArray(parsed) && parsed.length > 0) {
          setHistoryList(parsed);
        }
      }
    } catch (e) {
      console.error(e);
    }
  }, []);

  return (
    <div className="p-4 md:p-8 max-w-4xl mx-auto space-y-6">
      {/* Header with User Info */}
      <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-bambinos-600 text-white font-black flex items-center justify-center text-lg shadow-md">
            {userName.slice(0, 2).toUpperCase()}
          </div>
          <div>
            <h1 className="text-xl font-black text-slate-900">{userName}</h1>
            <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
              <span className="flex items-center gap-1 text-amber-500">
                <Flame className="w-4 h-4 fill-amber-500" /> 5 Streak
              </span>
              <span>•</span>
              <span className="text-bambinos-600 font-extrabold">Rated Player</span>
            </div>
          </div>
        </div>

        <Link
          href="/"
          className="py-3 px-6 bg-bambinos-600 hover:bg-bambinos-700 text-white font-black rounded-2xl shadow-lg shadow-bambinos-600/30 flex items-center gap-2"
        >
          <Play className="w-5 h-5 fill-white" /> Play Game
        </Link>
      </div>

      {/* Game History Header Bar */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between px-6 text-xs font-black text-slate-500 uppercase tracking-wider">
          <span>Game History ({historyList.length} matches)</span>
          <span>Accuracy</span>
        </div>

        {/* List of Played Games */}
        <div className="divide-y divide-slate-100">
          {historyList.map((item) => (
            <div key={item.id} className="p-4 px-6 flex items-center justify-between hover:bg-slate-50 transition-colors">
              {/* Left Opponent Info */}
              <div className="flex items-center gap-4">
                <Clock className="w-5 h-5 text-bambinos-600" />

                {/* Chess Piece DP */}
                <div className="w-10 h-10 rounded-xl bg-white border border-slate-200 flex items-center justify-center p-1.5 shadow-xs shrink-0">
                  <img
                    src={item.pieceIcon || '/pieces/wN.svg'}
                    alt="Chess Piece"
                    className="w-full h-full object-contain"
                  />
                </div>

                <div>
                  <div className="text-sm font-black text-slate-900 flex items-center gap-2">
                    {item.opponent}
                    {item.matchType && (
                      <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-slate-100 text-slate-600">
                        {item.matchType === 'invited' ? 'Invited' : item.matchType === 'pass_play' ? 'Pass & Play' : item.matchType === 'coach' ? 'Coach' : 'AI Bot'}
                      </span>
                    )}
                  </div>
                  <span className="text-xs font-semibold text-slate-400">
                    {item.date} {item.movesCount > 0 && `• ${item.movesCount} moves`}
                  </span>
                </div>
              </div>

              {/* Right Result & Accuracy */}
              <div className="flex items-center gap-4">
                {/* Win / Loss Icon */}
                <div className={`w-7 h-7 rounded-lg flex items-center justify-center text-white font-black ${
                  item.result === 'win' ? 'bg-emerald-500' : 'bg-rose-500'
                }`}>
                  {item.result === 'win' ? <Plus className="w-4 h-4" /> : <Minus className="w-4 h-4" />}
                </div>

                {/* Accuracy Percentage */}
                <span className="text-sm font-black text-slate-800 w-12 text-right">
                  {item.accuracy}%
                </span>

                {/* Game Review Star Button */}
                <button
                  onClick={() => alert(`Reviewing match: ${item.opponent}...`)}
                  className="w-10 h-10 rounded-xl bg-bambinos-600 text-white flex items-center justify-center hover:bg-bambinos-700 shadow-md transition-transform active:scale-95"
                >
                  <Star className="w-5 h-5 fill-white" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
